import React from 'react';

export const About = () => {
  return <div>
      <p>sdavbnxcl,mbndsjhvmsz:?hnal;bnm,vc/jnxjhslhnl.bnashjd</p>
  </div>;
};
